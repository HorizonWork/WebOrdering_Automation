# src/models/text_segmenter.py
from pyvi import ViTokenizer

class VietnameseSegmenter:
    """Vietnamese word segmenter using pyvi"""
    
    @staticmethod
    def segment(text: str) -> str:
        """
        Segment Vietnamese text into words.
        PhoBERT requires word-segmented input.
        
        Example:
            "Tìm kiếm sản phẩm" -> "Tìm_kiếm sản_phẩm"
        """
        return ViTokenizer.tokenize(text)
