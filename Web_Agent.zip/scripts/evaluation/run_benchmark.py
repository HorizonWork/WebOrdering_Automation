"""Benchmark runner entry point (migrated from scripts/evaluate_agent.py)."""
