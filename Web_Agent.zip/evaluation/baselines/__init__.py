﻿"""Baseline agents for benchmarking."""
