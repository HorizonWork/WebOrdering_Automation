﻿# Analysis for exp_002_ablation_no_thought

TODO: fill observations.
