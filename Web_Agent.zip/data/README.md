# Data Directory

This directory contains all training and evaluation data for WOA Agent.

## Structure

- `raw/`: Raw trajectories from browser automation
- `annotated/`: Gemini-labeled trajectories with thought/plan
- `processed/`: Final training data for ViT5
- `embeddings/`: Cached PhoBERT embeddings
- `trajectories/`: Episodes organized by success/failure
- `statistics/`: Dataset statistics for paper
- `annotation_quality/`: Quality control metrics

## Data Not in Git

All data files are gitignored due to size. To reproduce:
1. Run data collection: `python scripts/data_collection/collect_raw_trajectories.py`
2. Run annotation: `python scripts/annotation/batch_annotate.py`
3. Build training data: `python scripts/preprocessing/build_datasets.py`

See documentation in `docs/data_collection.md` for details.
