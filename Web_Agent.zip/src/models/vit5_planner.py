# src/models/vit5_planner.py
import json
import re
from typing import Dict, List, Optional

import torch
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer


class ViT5Planner:
    """ViT5-based planner for Vietnamese web automation (HF-only)."""

    def __init__(
        self,
        model_name: str = "VietAI/vit5-base",
        device: str = None,
        checkpoint_path: Optional[str] = None,
    ) -> None:
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

        if checkpoint_path:
            self.model = AutoModelForSeq2SeqLM.from_pretrained(checkpoint_path).to(self.device)
            self.tokenizer = AutoTokenizer.from_pretrained(checkpoint_path)
        else:
            self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name).to(self.device)
            self.tokenizer = AutoTokenizer.from_pretrained(model_name)

        self.model.eval()

    def generate_thought(
        self,
        query: str,
        observation: Dict,
        history: List[Dict],
        max_length: int = 128,
    ) -> str:
        prompt = self._create_thought_prompt(query, observation, history)
        return self._generate(prompt, max_length=max_length)

    def generate_action(
        self,
        query: str,
        observation: Dict,
        history: List[Dict],
        thought: str,
        available_skills: Optional[List[str]] = None,
        max_length: int = 128,
    ) -> Dict:
        prompt = self._create_action_prompt(query, observation, history, thought, available_skills)
        action_text = self._generate(prompt, max_length=max_length)
        return self._parse_action(action_text, available_skills)

    def _generate(self, prompt: str, max_length: int = 128) -> str:
        inputs = self.tokenizer(prompt, return_tensors="pt", max_length=512, truncation=True).to(self.device)
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=max_length,
                num_beams=4,
                temperature=0.7,
                do_sample=True,
                top_p=0.9,
                no_repeat_ngram_size=3,
            )
        return self.tokenizer.decode(outputs[0], skip_special_tokens=True).strip()

    def _create_thought_prompt(self, query: str, observation: Dict, history: List[Dict]) -> str:
        url = observation.get("url", "")
        elements_count = len(observation.get("elements", []))
        recent_actions = []
        for step in history[-3:]:
            action = step.get("action", {})
            recent_actions.append(f"{action.get('skill')}({action.get('params')})")
        recent_str = ", ".join(recent_actions) if recent_actions else "Chua co"
        prompt = "\n".join(
            [
                f"Nhiem vu: {query}",
                f"Trang hien tai: {url}",
                f"So luong phan tu: {elements_count}",
                f"Cac hanh dong gan day: {recent_str}",
                "",
                "Suy nghi ve buoc tiep theo:",
            ]
        )
        return prompt

    def _create_action_prompt(
        self,
        query: str,
        observation: Dict,
        history: List[Dict],
        thought: str,
        available_skills: Optional[List[str]],
    ) -> str:
        skills_str = ", ".join(available_skills) if available_skills else "click, type, goto, scroll"
        elements = observation.get("elements", [])[:5]
        elements_desc = "\n".join(
            [f"  - {e.get('tag')} (selector: {e.get('selector')}, text: {e.get('text', '')})" for e in elements]
        )
        prompt = "\n".join(
            [
                f"Nhiem vu: {query}",
                f"Suy nghi: {thought}",
                "",
                "Cac phan tu co the tuong tac:",
                elements_desc,
                "",
                f"Ky nang kha dung: {skills_str}",
                "",
                "Tao hanh dong (dinh dang JSON):",
            ]
        )
        return prompt

    def _parse_action(self, action_text: str, available_skills: Optional[List[str]] = None) -> Dict:
        try:
            match = re.search(r"\{[^}]+\}", action_text)
            if match:
                action = json.loads(match.group())
                if "skill" in action and "params" in action:
                    return {
                        "skill": action["skill"],
                        "params": action["params"],
                        "confidence": action.get("confidence", 0.8),
                    }
        except json.JSONDecodeError:
            pass

        skill = self._extract_skill(action_text, available_skills)
        params = self._extract_params(action_text, skill)
        return {"skill": skill, "params": params, "confidence": 0.5}

    def _extract_skill(self, text: str, available_skills: Optional[List[str]]) -> str:
        default_skills = ["click", "type", "goto", "scroll", "wait", "complete"]
        skills = available_skills or default_skills
        lower = text.lower()
        for s in skills:
            if s in lower:
                return s
        return "wait"

    def _extract_params(self, text: str, skill: str) -> Dict:
        if skill == "click":
            selector_match = re.search(r"[#.][\w-]+", text)
            return {"selector": selector_match.group() if selector_match else "#button"}
        if skill == "type":
            text_match = re.search(r'"([^"]+)"', text)
            selector_match = re.search(r"[#.][\w-]+", text)
            return {
                "selector": selector_match.group() if selector_match else "#input",
                "text": text_match.group(1) if text_match else "",
            }
        if skill == "goto":
            url_match = re.search(r"https?://[^\s]+", text)
            return {"url": url_match.group() if url_match else ""}
        if skill == "scroll":
            return {"direction": "down", "amount": 500}
        return {}
