# src/models/phobert_encoder.py
import torch
from transformers import AutoModel, AutoTokenizer
import numpy as np
from typing import Union, List

class PhoBERTEncoder:
    """
    PhoBERT encoder for Vietnamese text embedding.
    Uses vinai/phobert-base-v2 pre-trained model.
    """
    
    def __init__(
        self,
        model_name: str = "vinai/phobert-base-v2",
        device: str = None
    ):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        
        # Load PhoBERT model and tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name).to(self.device)
        self.model.eval()  # Set to evaluation mode
        
        self.embedding_dim = 768  # PhoBERT base output dimension
    
    def encode_text(
        self,
        texts: Union[str, List[str]],
        max_length: int = 256,
        normalize: bool = True
    ) -> np.ndarray:
        """
        Encode Vietnamese text to embeddings.
        
        Args:
            texts: Single text or list of texts (MUST be word-segmented for PhoBERT)
            max_length: Max sequence length
            normalize: Whether to L2-normalize embeddings
            
        Returns:
            Embeddings array (batch_size, 768)
        """
        # Ensure input is list
        is_single = isinstance(texts, str)
        if is_single:
            texts = [texts]
        
        # Tokenize (PhoBERT expects word-segmented input)
        encoded = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=max_length,
            return_tensors="pt"
        ).to(self.device)
        
        # Get embeddings
        with torch.no_grad():
            outputs = self.model(**encoded)
            # Use [CLS] token embedding (first token)
            embeddings = outputs.last_hidden_state[:, 0, :].cpu().numpy()
        
        # Normalize if requested
        if normalize:
            norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
            embeddings = embeddings / (norms + 1e-8)
        
        # Return single embedding if input was single text
        return embeddings[0:1] if is_single else embeddings
